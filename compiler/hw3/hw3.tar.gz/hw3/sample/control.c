int main() {
	int i;
        int p;
        int k, j;
	for (i=0; i<9; i=i+1) {
            /* empty */
	}
        for (i=0, p=4+4; i<9; i=i+1, p=i) {
            write("test");
        }
        for (;;) {
            /*empty*/
        }
        while (1) {
        }
        while (2) {
            write("haha");
            write("wow");
        }
        if (k == j) {
            write("first");
        }
        if (k == j) {
            write("first");
        } else if (j == k) {
            write("second");
        } else {
            write("third");
        }
}
