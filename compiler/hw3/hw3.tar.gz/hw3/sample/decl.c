int ABC;
float ABCD, AAA = 4.0, KKK = 5.5;
typedef float GFLOAT;
int main() {
    typedef int INT, INT2, INT3;
    typedef float FLOAT;
    typedef void VOID;
    typedef void VOID2, VOID3;
    INT f[3][3*3-(4+2)/2];
    FLOAT f2;
}
